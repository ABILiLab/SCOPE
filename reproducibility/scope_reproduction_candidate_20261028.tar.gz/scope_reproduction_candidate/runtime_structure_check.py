import sys,types,json,os,shutil
from pathlib import Path
import numpy as np,pandas as pd
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P));os.chdir(P)
from Bio.Data import PDBData
m=types.ModuleType('Bio.Data.SCOPData');m.protein_letters_3to1=PDBData.protein_letters_3to1;sys.modules[m.__name__]=m
if not hasattr(pd.DataFrame,'append'):
    pd.DataFrame.append=lambda self,other,ignore_index=True,**kw:pd.concat([self,other.to_frame().T if isinstance(other,pd.Series) else other],ignore_index=ignore_index)
import feature_extract as fe
# Biopython's formatted alignment now has coordinates and wrapped lines.
# Read the alignment rows directly rather than parsing its display string.
src=(P/'biotoolbox/contact_map_builder.py').read_text()
src=src.replace('aligned_seqres_seq, mask, aligned_atom_seq = pattern[:3]',"aligned_seqres_seq, aligned_atom_seq = specific_alignment[0], specific_alignment[1]\n                mask = ''.join('|' if a == b else '.' for a,b in zip(aligned_seqres_seq,aligned_atom_seq))")
patched=types.ModuleType('runtime_contact_builder');exec(compile(src,'runtime_contact_builder','exec'),patched.__dict__)
fe.DistanceMapBuilder=patched.DistanceMapBuilder
def generate(protein,seq,data):
    from Bio.PDB import PDBParser
    import pickle
    chain=PDBParser(QUIET=True).get_structure(protein,str(data/'PDB/SavechainPDB'/(protein+'.pdb')))[0][protein.split('-')[1]]
    residues=[r for r in chain if r.id[0]==' ']
    # These fixed benchmark PDBs use reference-sequence numbering. Verify every
    # identity before using it; never guess mappings or synthesize coordinates.
    assert all(r.id[2]==' ' and 1<=r.id[1]<=len(seq) and fe.res_dict[r.resname]==seq[r.id[1]-1] for r in residues)
    ordered=[None]*len(seq)
    for r in residues: ordered[r.id[1]-1]=r
    mapper=fe.DistanceMapBuilder(atom='CA',verbose=False)
    distances=mapper._DistanceMapBuilder__residue_list_to_contact_map(ordered,len(seq))
    (data/'contact_map').mkdir(exist_ok=True)
    np.save(data/'contact_map'/(protein+'.npy'),distances)
    fe.get_pdb_DF(protein,str(data)+'/');fe.cal_atomFea([protein],str(data)+'/')
    meta=pickle.loads((data/'Atom_feas'/(protein+'.csv.pkl')).read_bytes())
    raw=np.load(data/'Atom_feas/processed_atomfea'/(protein+'.npy')).reshape(-1,7)
    atom=np.zeros((len(seq),7))
    assert len(raw)==len(meta['res_id_list'])
    for j,(rid,aa) in enumerate(zip(meta['res_id_list'],meta['sequence'])):
        assert seq[rid-1]==aa
        atom[rid-1]=raw[j]
    (data/'Atom_feas/matched_atomfea').mkdir(exist_ok=True)
    np.save(data/'Atom_feas/matched_atomfea'/(protein+'.npy'),atom)
    fe.seq_fea_generate(protein,seq,str(data)+'/')
    for sub,shape in [('contact_map',(len(seq),len(seq))),('Atom_feas/matched_atomfea',(len(seq),7)),('seqfea',(len(seq),7))]:
        a=np.load(data/sub/(protein+'.npy'));assert a.shape==shape,(protein,sub,a.shape);assert np.isfinite(a).all(),(protein,sub)
