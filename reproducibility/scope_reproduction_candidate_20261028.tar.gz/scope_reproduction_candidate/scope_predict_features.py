"""Run the bundled SCOPE entry on existing, validated feature files."""
import argparse,os,shutil,subprocess,sys,json,tempfile
from pathlib import Path
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--features',type=Path,required=True)
 p.add_argument('--checkpoint',type=Path,required=True)
 p.add_argument('--output',type=Path,required=True)
 p.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parent)
 p.add_argument('--device',default='cpu',help='cpu or physical GPU index')
 a=p.parse_args()
 for f in [a.features/'pdb_ids.txt',a.checkpoint,a.bundle/'infer.py',a.bundle/'scope_model_utils.py']:
  if not f.is_file():p.error('Missing required file: '+str(f))
 if a.output.exists():p.error('Output already exists; choose a fresh directory')
 a.output.mkdir(parents=True)
 env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']='' if a.device=='cpu' else a.device;env['SCOPE_DEVICE']='cpu' if a.device=='cpu' else 'cuda:0'
 for name in ['infer.py','scope_model_utils.py']:shutil.copy2(a.bundle/name,a.output/name)
 (a.output/'Example').symlink_to(a.features.resolve(),target_is_directory=True)
 (a.output/'checkpoints').mkdir();(a.output/'checkpoints/best.pth').symlink_to(a.checkpoint.resolve())
 with (a.output/'run.log').open('w') as f:
  subprocess.run([sys.executable,'infer.py'],cwd=a.output,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 ids=(a.features/'pdb_ids.txt').read_text().split()
 for pid in ids:
  result=a.output/'InferResult'/pid
  if not result.is_file() or not result.stat().st_size:raise RuntimeError('Missing output: '+pid)
 (a.output/'completed.json').write_text(json.dumps(dict(state='complete',proteins=ids,scope='Inference from existing features, not end-to-end feature generation.'),indent=2))
if __name__=='__main__':main()
