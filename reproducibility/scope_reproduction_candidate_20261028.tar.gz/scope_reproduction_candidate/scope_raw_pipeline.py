"""Configurable sequence/PDB-to-prediction entry for sequence-numbered PDB chains."""
import argparse,json,os,sys,shutil,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--config',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
c=json.loads(a.config.read_text());O=a.output.resolve();B=Path(__file__).resolve().parent
if O.exists():p.error('Choose a fresh output directory')
pid=c['protein'];assert '/' not in pid and '\\' not in pid and '..' not in pid
lines=[x.strip() for x in Path(c['fasta']).read_text().splitlines() if x.strip()]
assert lines[0].startswith('>') and sum(x.startswith('>') for x in lines)==1
seq=''.join(lines[1:]);assert 1<len(seq)<=1000,'This validated entry supports lengths 2-1000 only'
for k in ['pdb','checkpoint']:assert Path(c[k]).is_file(),k
assert Path(c['prott5']).is_dir()
O.mkdir(parents=True);D=O/'features';start=time.monotonic()
def state(s,**kw):(O/'status.json').write_text(json.dumps(dict(state=s,time=time.strftime('%Y-%m-%d %H:%M:%S'),**kw),indent=2))
os.environ['CUDA_VISIBLE_DEVICES']='';os.environ['SCOPE_DEVICE']='cpu';os.environ['SCOPE_PROTT5_DIR']=c['prott5']
os.environ['OMP_NUM_THREADS']=str(c.get('threads',4))
try:
 for sub in ['fasta','pssm/processed_pssm','hhm/processed_hhm','PDB/SavechainPDB','Atom_feas','seqfea','Prot5']:(D/sub).mkdir(parents=True,exist_ok=True)
 (D/'fasta'/f'{pid}.fa').write_text('>'+pid+'\n'+seq+'\n');shutil.copy2(c['pdb'],D/'PDB/SavechainPDB'/f'{pid}.pdb')
 commands={k:[s.replace('{features}',str(D)).replace('{protein}',pid) for s in cmd] for k,cmd in c['search_commands'].items()}
 (O/'resolved_commands.json').write_text(json.dumps(commands,indent=2))
 for name,cmd in commands.items():
  state('running_'+name)
  with (O/(name+'.log')).open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 state('structure_and_profile_features');sys.path.insert(0,str(B));from runtime_structure_check import generate,fe
 fe.cal_PSSM([pid],str(D/'pssm')+'/');fe.cal_HMM([pid],str(D/'hhm')+'/');generate(pid,seq,D)
 state('cpu_prott5_embedding');import torch;torch.set_num_threads(c.get('threads',4))
 import evofea_embedding as emb
 model,tokenizer=emb.get_T5_model();result=emb.get_embeddings(model,tokenizer,{pid:seq},True,False,max_batch=1)
 emb.save_embeddings(result['residue_embs'],D/'Prot5/train_per_residue_embeddings.h5');del model,tokenizer,result
 import gc;gc.collect();(D/'pdb_ids.txt').write_text(pid+'\n');state('cpu_prediction')
 subprocess.run([sys.executable,str(B/'scope_predict_features.py'),'--features',str(D),'--checkpoint',c['checkpoint'],'--output',str(O/'prediction'),'--device','cpu'],check=True)
 rows=[r.split() for r in (O/'prediction/InferResult'/pid).read_text().splitlines()]
 assert ''.join(r[0] for r in rows)==seq and len(rows)==len(seq)
 state('complete',n_residues=len(seq),elapsed_seconds=time.monotonic()-start,scope='Fresh feature generation and prediction using configurable bundled CPU entry and existing external assets. Not clean installation.')
except Exception as e:state('failed',error=repr(e));raise
